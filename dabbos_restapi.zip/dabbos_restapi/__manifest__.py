{
    "name": "Dabbos Rest API",
    "version": "17.0",
    "category": "API",
    "summary": "Dabbos Rest API",

    "depends": ["web", "base_setup", 'account','sale_management','stock','dabbos_reports'],
    "data": ["views/ir_model.xml", "views/res_users.xml", "security/ir.model.access.csv",],

}
