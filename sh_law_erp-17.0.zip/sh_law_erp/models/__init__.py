# -*- coding: utf-8 -*-

from . import law_practise_area
from . import metter_type
from . import matter_category
from . import client_request
from . import hr
from . import evidence
from . import trial
from . import favor
from . import matter
from . import courts
from . import account_move
from . import judge
from . import customer
from . import opposition_lawyer
from . import opposition_parties
from . import victim
from . import act_article
from . import corp

